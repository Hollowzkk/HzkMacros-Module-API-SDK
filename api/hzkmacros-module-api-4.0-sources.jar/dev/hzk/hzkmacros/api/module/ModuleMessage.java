package dev.hzk.hzkmacros.api.module;

import java.util.Map;
import java.util.Objects;

/** Immutable message published on the lightweight inter-module message bus. */
public record ModuleMessage(String sourceModuleId, String topic, Map<String, ModuleValue> values) {
    public ModuleMessage {
        sourceModuleId = Objects.requireNonNull(sourceModuleId, "sourceModuleId");
        topic = Objects.requireNonNull(topic, "topic");
        values = Map.copyOf(Objects.requireNonNull(values, "values"));
    }
}
