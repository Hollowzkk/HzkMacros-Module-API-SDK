package dev.hzk.hzkmacros.api.module;

/**
 * Small client-tick scheduler supplied by the host.
 * Callbacks run on the Minecraft client tick thread and must not block it.
 */
public interface ModuleScheduler {
    /** Schedules a one-shot task. delayTicks=0 runs on the next host tick. */
    ModuleTask schedule(long delayTicks, Runnable task);

    /** Schedules a repeating task. The first run occurs after initialDelayTicks. */
    ModuleTask repeat(long initialDelayTicks, long intervalTicks, Runnable task);

    /** Current host client-tick counter. */
    long currentTick();

    default ModuleTask execute(Runnable task) { return schedule(0, task); }
}
