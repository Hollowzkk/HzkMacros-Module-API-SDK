package dev.hzk.hzkmacros.api.module;

/** Removable message-bus subscription. Closing it is idempotent. */
public interface ModuleSubscription extends AutoCloseable {
    boolean active();
    @Override void close();
}
