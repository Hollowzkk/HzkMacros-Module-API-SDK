package dev.hzk.hzkmacros.api.module;

/** Cooperative result: a wait resumes at the NEXT statement, not the current one. */
public record ModuleResult(long waitTicks) {
    public ModuleResult { if (waitTicks < 0 || waitTicks > 72000) throw new IllegalArgumentException("Invalid wait ticks"); }
    public static ModuleResult done() { return new ModuleResult(0); }
    public static ModuleResult waitTicks(long ticks) { return new ModuleResult(ticks); }
}
