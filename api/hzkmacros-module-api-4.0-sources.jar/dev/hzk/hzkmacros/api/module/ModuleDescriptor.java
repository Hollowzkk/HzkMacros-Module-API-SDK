package dev.hzk.hzkmacros.api.module;

import java.util.List;
import java.util.Objects;

/** Immutable identity and declared dependency information for one loaded module. */
public record ModuleDescriptor(String id, String name, String version, String author,
                               int apiVersion, List<String> dependencies) {
    public ModuleDescriptor {
        id = Objects.requireNonNull(id, "id");
        name = Objects.requireNonNull(name, "name");
        version = Objects.requireNonNull(version, "version");
        author = Objects.requireNonNull(author, "author");
        dependencies = List.copyOf(Objects.requireNonNull(dependencies, "dependencies"));
    }
}
