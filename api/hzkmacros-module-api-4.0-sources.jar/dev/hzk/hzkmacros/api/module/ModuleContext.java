package dev.hzk.hzkmacros.api.module;

import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

/** Versioned HzkMacros module host context. Registration methods are valid only during onLoad. */
public interface ModuleContext {
    String moduleId();
    void registerAction(String name, ModuleAction action);

    /** API v2; variables use typed names such as &my_module_status or #my_module_count. */
    default void registerVariable(String name, ModuleVariable provider) {
        throw new UnsupportedOperationException("Module API v2 is required for variable providers");
    }

    /** API v2; returns bounded rows for FOREACH(my_module_items). */
    default void registerIterator(String name, ModuleIterator provider) {
        throw new UnsupportedOperationException("Module API v2 is required for iterators");
    }

    /** API v2; events can be consumed by WAITEVENT(my_module_updated). */
    default ModuleEvent registerEvent(String name) {
        throw new UnsupportedOperationException("Module API v2 is required for events");
    }

    /** API v3; immutable identity for the current module. */
    default ModuleDescriptor descriptor() {
        throw new UnsupportedOperationException("Module API v3 is required for module descriptors");
    }

    /** API v3; scoped logger available for the entire lifetime of the module. */
    default ModuleLogger logger() {
        throw new UnsupportedOperationException("Module API v3 is required for module logging");
    }

    /** API v3; publish and consume typed Java services between module dependencies. */
    default ModuleServices services() {
        throw new UnsupportedOperationException("Module API v3 is required for module services");
    }

    /** API v3; lightweight namespaced message bus. */
    default ModuleMessageBus messages() {
        throw new UnsupportedOperationException("Module API v3 is required for module messages");
    }

    /** API v3; persistent writable directory dedicated to this module. */
    default Path dataDirectory() {
        throw new UnsupportedOperationException("Module API v3 is required for module storage");
    }

    /** API v3; reports modules that completed loading before this module. */
    default boolean isModuleLoaded(String id) {
        throw new UnsupportedOperationException("Module API v3 is required for module introspection");
    }

    /** API v4; returns public metadata for a loaded module. */
    default Optional<ModuleDescriptor> findModule(String id) {
        throw new UnsupportedOperationException("Module API v4 is required for module introspection");
    }

    /** API v4; immutable snapshot of modules that have completed loading. */
    default List<ModuleDescriptor> loadedModules() {
        throw new UnsupportedOperationException("Module API v4 is required for module introspection");
    }

    /** API v4; bounded scheduler drained on the Minecraft client tick thread. */
    default ModuleScheduler scheduler() {
        throw new UnsupportedOperationException("Module API v4 is required for module scheduling");
    }
}
