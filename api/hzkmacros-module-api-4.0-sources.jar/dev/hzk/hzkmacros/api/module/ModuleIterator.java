package dev.hzk.hzkmacros.api.module;

import java.util.List;
import java.util.Map;

/** Returns a finite snapshot for one FOREACH invocation, not a live iterator. */
@FunctionalInterface
public interface ModuleIterator {
    List<Map<String, ModuleValue>> snapshot();
}
