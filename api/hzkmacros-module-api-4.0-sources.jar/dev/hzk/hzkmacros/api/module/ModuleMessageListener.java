package dev.hzk.hzkmacros.api.module;

/** Listener invoked synchronously on the thread that published the message. Do not block it. */
@FunctionalInterface
public interface ModuleMessageListener {
    void onMessage(ModuleMessage message) throws Exception;
}
