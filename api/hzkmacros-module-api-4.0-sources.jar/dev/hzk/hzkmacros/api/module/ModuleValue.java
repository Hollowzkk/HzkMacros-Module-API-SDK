package dev.hzk.hzkmacros.api.module;

import java.util.Objects;

/** Immutable typed value supplied by a module without leaking engine internals. */
public record ModuleValue(Type type, Object value) {
    public enum Type { STRING, INTEGER, FLOAT, BOOLEAN }
    public ModuleValue {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(value, "value");
        if (!(switch (type) {
            case STRING -> value instanceof String;
            case INTEGER -> value instanceof Integer;
            case FLOAT -> value instanceof Double;
            case BOOLEAN -> value instanceof Boolean;
        })) throw new IllegalArgumentException("Value does not match its declared type");
        if (type == Type.FLOAT && !Double.isFinite((Double) value))
            throw new IllegalArgumentException("Nonfinite module number");
    }
    public static ModuleValue string(String value) { return new ModuleValue(Type.STRING, Objects.requireNonNull(value)); }
    public static ModuleValue integer(int value) { return new ModuleValue(Type.INTEGER, value); }
    public static ModuleValue floatNumber(double value) {
        if (!Double.isFinite(value)) throw new IllegalArgumentException("Nonfinite module number");
        return new ModuleValue(Type.FLOAT, value);
    }
    public static ModuleValue bool(boolean value) { return new ModuleValue(Type.BOOLEAN, value); }
}
