package dev.hzk.hzkmacros.api.module;

/** Logger scoped to a module. Messages are routed through the HzkMacros logger. */
public interface ModuleLogger {
    void info(String message);
    void warn(String message);
    void error(String message, Throwable error);
    default void error(String message) { error(message, null); }
}
