package dev.hzk.hzkmacros.api.module;

import java.util.Map;

/** Event handle issued during registration. Publish only after onLoad returns. */
@FunctionalInterface
public interface ModuleEvent {
    void emit(Map<String, ModuleValue> variables);
    default void emit() { emit(Map.of()); }
}
