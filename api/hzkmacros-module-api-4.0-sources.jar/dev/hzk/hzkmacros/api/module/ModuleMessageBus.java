package dev.hzk.hzkmacros.api.module;

import java.util.Map;

/** Lightweight module-to-module notifications; use services for richer typed integrations. */
public interface ModuleMessageBus {
    /** Subscribes to a fully-qualified topic such as provider_id:status.changed. */
    ModuleSubscription subscribe(String qualifiedTopic, ModuleMessageListener listener);

    /** Publishes a topic owned by the current module; it becomes module_id:topic. */
    void publish(String topic, Map<String, ModuleValue> values);

    default void publish(String topic) { publish(topic, Map.of()); }
}
