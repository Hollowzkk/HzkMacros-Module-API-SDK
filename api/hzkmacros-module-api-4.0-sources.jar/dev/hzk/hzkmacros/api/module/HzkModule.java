package dev.hzk.hzkmacros.api.module;

/** Public entrypoint for a locally installed HzkMacros module. */
public interface HzkModule {
    /** Called once at startup. Register capabilities and initialize the module here. */
    void onLoad(ModuleContext context) throws Exception;

    /** Called once when the host suspends or shuts down this module, dependents first.
     * A full Java/Fabric class unload still requires restarting Minecraft. API v1/v2 modules may ignore it.
     */
    default void onUnload() throws Exception { }
}
