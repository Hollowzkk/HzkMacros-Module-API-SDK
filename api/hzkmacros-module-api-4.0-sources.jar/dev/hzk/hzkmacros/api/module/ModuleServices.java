package dev.hzk.hzkmacros.api.module;

import java.util.NoSuchElementException;
import java.util.Optional;

/** Runtime service exchange between loaded modules. Custom service types live in provider modules. */
public interface ModuleServices {
    /** Registers a service owned by the current module. Registration is allowed only during onLoad. */
    void register(String name, Object service);

    /** Looks up a service exported by another loaded module (or the current module). */
    <T> Optional<T> find(String moduleId, String name, Class<T> type);

    default <T> T require(String moduleId, String name, Class<T> type) {
        return find(moduleId, name, type).orElseThrow(() ->
            new NoSuchElementException("Missing module service " + moduleId + ":" + name));
    }
}
