package dev.hzk.hzkmacros.api.module;

/** Handle for a task scheduled through the HzkMacros module host. */
public interface ModuleTask {
    boolean active();
    void cancel();
}
