package dev.hzk.hzkmacros.api.module;

import java.util.List;

/** Snapshot of expanded macro arguments. Module code cannot mutate engine state. */
public interface ModuleInvocation {
    String moduleId();
    List<String> arguments();
    default String argument(int index, String fallback) {
        return index >= 0 && index < arguments().size() ? arguments().get(index) : fallback;
    }
    void log(String message);
}
