package dev.hzk.hzkmacros.api.module;

/** One invocation on the Minecraft client thread. Do not block the tick. */
@FunctionalInterface
public interface ModuleAction {
    ModuleResult execute(ModuleInvocation invocation) throws Exception;
}
