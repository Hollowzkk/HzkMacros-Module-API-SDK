package dev.hzk.hzkmacros.api.module;

/** Lazy read-only provider; invoked during macro variable expansion on the client thread. */
@FunctionalInterface
public interface ModuleVariable {
    ModuleValue read();
}
